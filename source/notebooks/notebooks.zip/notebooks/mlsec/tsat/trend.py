import numpy as np

# def timeseries_slope(ts, order=1):
#     result = np.polyfit(range(len(ts)), list(ts), order)
#     slope = result[-2]
#     return float(slope)
